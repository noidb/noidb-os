(function () {
  "use strict";
  // 0.9.9(2026-10-11): 쿠팡은 메뉴로 이동할 때 페이지를 새로 열지 않아 칸이 안 뜨던 문제 →
  // 쿠팡 모든 화면에 들어가 있다가, 주소가 쉽먼트 목록일 때만 칸을 붙이고(화면이 다시 그려져 빠지면 다시 붙임) 다른 화면에선 뗀다.
  const PANEL_PATH = "/ibs/asn/active";
  if (document.getElementById("noidb-shipment-reader")) return;
  const panel = document.createElement("section");
  panel.id = "noidb-shipment-reader";
  panel.style.cssText = "padding:16px;margin:16px;border:2px solid #55735c;border-radius:10px;background:#f3f7f1;color:#29352f";
  panel.innerHTML = '<h3>NOID-B 쉽먼트 입고결과</h3><p>입고예정일 9/13 이후 마감된 쉽먼트 중 새로 마감된 것만 읽습니다. 쿠팡 자료는 변경하지 않습니다.</p><div><button type="button" data-action="collect">입고결과 일괄 가져오기</button> <button type="button" data-action="cancel" hidden>중단</button> <button type="button" data-action="retry" disabled>NOID-B 전송 재시도</button> <button type="button" data-action="download" disabled>자료 파일 저장</button></div><p role="status" aria-live="polite"></p><div data-pdf style="margin-top:10px;padding:10px;border-top:1px solid #c9d6cb"><strong>Label·내역서 PDF 자동 저장</strong><p style="margin:4px 0">Label·내역서를 누르면 컴퓨터로 받지 않고 G드라이브 「쉽먼트출력세트/입고예정일(예: 20261023)」 폴더에 바로 저장합니다(폴더가 없으면 새로 만듦, 저장 창 없음).</p><div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:6px 0"><label>입고예정일 <select data-pdf-date style="height:30px;border-radius:8px"></select></label><label>확인할 쪽 <select data-pdf-pages style="height:30px;border-radius:8px"><option value="1" selected>1쪽까지</option><option value="2">2쪽까지</option><option value="3">3쪽까지</option><option value="4">4쪽까지</option><option value="5">5쪽까지</option></select></label><button type="button" data-action="pdf-all" style="height:30px;padding:0 12px;border:1px solid #c9d6cb;border-radius:8px;background:#e3ede6;font-weight:700;cursor:pointer">이 날짜 Label·내역서 전부 받기</button><button type="button" data-action="pdf-folder" style="height:30px;padding:0 12px;border:1px solid #d8c9b6;border-radius:8px;background:#e9ddcf;font-weight:700;cursor:pointer">저장 폴더 열기</button></div><p data-pdf-batch style="margin:4px 0"></p><p data-pdf-status style="margin:4px 0">아직 받은 PDF 없음</p><p data-pdf-url style="margin:4px 0;font-size:11px;color:#5d6b62"></p></div>';
  function placePanel() {
    if (location.pathname === PANEL_PATH) {
      if (!panel.isConnected) (document.querySelector("#app") || document.body).prepend(panel);
    } else if (panel.isConnected && !controller) panel.remove();
  }
  const status = panel.querySelector('[role="status"]');
  const collect = panel.querySelector('[data-action="collect"]'), cancel = panel.querySelector('[data-action="cancel"]');
  const retry = panel.querySelector('[data-action="retry"]'), download = panel.querySelector('[data-action="download"]');
  let result = null, controller = null;
  async function save() {
    if (!result) return;
    retry.disabled = collect.disabled = true;
    status.textContent = "NOID-B에 저장 중…";
    try {
      const response = await chrome.runtime.sendMessage({ type: "NOIDB_SAVE_LOGISTICS_RECEIPTS", payload: result });
      if (!response?.ok) throw new Error(response?.error || "저장 여부를 확인하지 못했습니다. 자료 파일을 저장해 주세요.");
      status.textContent = `NOID-B 저장 완료 · 새로 ${result.shipments.length}건 추가, 전체 쉽먼트 ${response.count}건.`;
      download.disabled = retry.disabled = true;
    } catch (error) {
      status.textContent = `${error.message} 자료 파일을 저장하거나 전송을 재시도해 주세요.`;
      retry.disabled = download.disabled = false;
    } finally { collect.disabled = false; }
  }
  collect.addEventListener("click", async () => {
    result = null; collect.disabled = true; retry.disabled = download.disabled = true; cancel.hidden = false;
    controller = new AbortController();
    try {
      status.textContent = "NOID-B의 수집 대상을 확인 중…";
      const targets = await chrome.runtime.sendMessage({ type: "NOIDB_GET_LOGISTICS_RECEIPT_TARGETS" });
      if (!targets?.ok || !Array.isArray(targets.targets)) throw new Error(targets?.error || "NOID-B의 쉽먼트 수집 기능이 아직 준비되지 않았습니다.");
      const report = message => { status.textContent = message; };
      result = targets.collectionMode === "hub-closed"
        ? await NoidbShipmentReceipts.collectClosedSince(targets.since, report, controller.signal, targets.knownShipmentNumbers)
        : await NoidbShipmentReceipts.collectShipments(targets.targets, report, controller.signal);
      if (result?.nothingNew) {
        status.textContent = `새로 마감된 쉽먼트가 없습니다. 쿠팡 마감 ${result.closedCount}건은 모두 이미 NOID-B에 있습니다.`;
        result = null;
        return;
      }
      const closed = result.shipments.filter(item => item.status === "마감").length;
      status.textContent = `조회 완료 · 새로 마감된 쉽먼트 ${closed}건. NOID-B에 자동 전송합니다.`;
      await save();
    } catch (error) {
      status.textContent = error.name === "AbortError" ? "중단했습니다. 일부 자료를 완료로 저장하지 않았습니다." : error.message;
    } finally { controller = null; collect.disabled = false; cancel.hidden = true; }
  });
  cancel.addEventListener("click", () => controller?.abort());
  retry.addEventListener("click", save);
  download.addEventListener("click", () => {
    if (!result) return;
    const url = URL.createObjectURL(new Blob([JSON.stringify(result, null, 2)], { type: "application/json" }));
    const link = document.createElement("a"); link.href = url; link.download = `NOIDB_쉽먼트입고_${result.collectedAt.replace(/[:.]/g, "-")}.json`;
    document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000);
  });
  // 0.9.10: PDF 자동 저장 결과
  const pdfStatus = panel.querySelector("[data-pdf-status]"), pdfUrl = panel.querySelector("[data-pdf-url]");
  let pdfSaved = 0, pdfFailed = 0, pendingSaves = 0, lastPdfEventAt = 0;
  // 0.9.11: 크롬 다운로드에서 잡은 PDF 결과도 같은 칸에 보여 준다.
  try {
    chrome.runtime.onMessage.addListener(message => {
      if (message?.type === "NOIDB_PDF_STATUS") document.dispatchEvent(new CustomEvent("noidb-shipment-pdf", { detail: message.detail }));
    });
  } catch {}
  document.addEventListener("noidb-shipment-pdf", event => {
    const detail = event.detail || {};
    const label = detail.kind === "ManiFest" ? "내역서" : "Label";
    if (detail.phase === "sending") { pendingSaves += 1; lastPdfEventAt = Date.now(); }
    else if (detail.phase === "saved" || detail.phase === "failed") { pendingSaves = Math.max(0, pendingSaves - 1); lastPdfEventAt = Date.now(); }
    if (detail.phase === "sending") pdfStatus.textContent = `${label} PDF를 NOID-B에 저장하는 중…`;
    else if (detail.phase === "saved") { pdfSaved += 1; pdfStatus.textContent = `저장 완료 ${pdfSaved}개${pdfFailed ? ` · 실패 ${pdfFailed}개` : ""} · 최근: ${detail.folder ? `${detail.folder}/` : ""}${detail.name}${detail.skipped ? " (이미 저장돼 있음)" : ""}`; }
    else if (detail.phase === "failed") { pdfFailed += 1; pdfStatus.textContent = `저장 실패: ${detail.error} — 이 PDF는 예전처럼 G드라이브 폴더에 직접 저장해 주세요.`; }
    // 다음 버전에서 '한 번에 전부 받기'를 만들 수 있도록 쿠팡이 PDF를 주는 주소를 보여 준다.
    if (detail.url) pdfUrl.textContent = `받은 주소: ${detail.url}`;
    if (detail.phase === "saved") rememberDone(detail.name, detail.kind);
  });

  // 0.9.11(2026-10-21): '이 날짜 Label·내역서 전부 받기' — 화면 목록에서 고른 입고예정일 쉽먼트의 [Label]·[내역서]를 차례로 눌러 받는다.
  // 이미 받아 저장된 쉽먼트·종류는 건너뛰어 같은 파일을 두 번 받지 않는다(30일 기억). 쿠팡 자료는 바꾸지 않고 받기 버튼만 누른다.
  const DONE_KEY = "noidbShipmentPdfDone2"; // 0.9.13: 날짜 폴더로 바꾸며 새로 기억(다시 받으면 예전 저장분은 날짜 폴더로 옮겨짐)
  const pageSelect = panel.querySelector("[data-pdf-pages]"), dateSelect = panel.querySelector("[data-pdf-date]"), pdfAll = panel.querySelector('[data-action="pdf-all"]'), pdfBatch = panel.querySelector("[data-pdf-batch]");
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  async function readDone() {
    try { const stored = await chrome.storage.local.get(DONE_KEY); return stored[DONE_KEY] || {}; } catch { return {}; }
  }
  async function rememberDone(name, kind) {
    const shipment = String(name || "").match(/\((\d{5,})\)/)?.[1];
    if (!shipment || !kind) return;
    const done = await readDone();
    const cutoff = Date.now() - 30 * 86400000;
    for (const [key, at] of Object.entries(done)) if (Date.parse(at) < cutoff) delete done[key];
    done[`${shipment}:${kind}`] = new Date().toISOString();
    try { await chrome.storage.local.set({ [DONE_KEY]: done }); } catch {}
  }
  const textOf = element => (element?.textContent || "").replace(/\s+/g, " ").trim();
  /** 화면 목록에서 [Label]·[내역서] 버튼이 있는 줄만 읽는다. 입고예정일은 시각 없이 날짜만 있는 칸(발송일은 시각이 붙어 있음). */
  function shipmentRows() {
    return [...document.querySelectorAll("tr")].map(row => {
      const buttons = [...row.querySelectorAll("button, a")];
      const label = buttons.find(button => textOf(button) === "Label");
      const manifest = buttons.find(button => textOf(button) === "내역서");
      if (!label && !manifest) return null;
      const cells = [...row.children].map(textOf);
      const shipment = cells.find(text => /^\d{6,}$/.test(text)) || "";
      const date = cells.find(text => /^\d{4}-\d{2}-\d{2}$/.test(text)) || "";
      return shipment && date ? { shipment, date, label, manifest } : null;
    }).filter(Boolean);
  }
  let dateKey = "", pdfBusy = false;
  function refreshDates() {
    if (!panel.isConnected || pdfBusy) return;
    const counts = {};
    for (const row of shipmentRows()) counts[row.date] = (counts[row.date] || 0) + 1;
    const dates = Object.keys(counts).sort();
    const key = dates.map(date => `${date}:${counts[date]}`).join(",");
    if (key === dateKey) return;
    dateKey = key;
    const previous = dateSelect.value;
    const today = new Date(Date.now() + 9 * 3600000).toISOString().slice(0, 10);
    dateSelect.innerHTML = dates.length ? dates.map(date => `<option value="${date}">${date} (${counts[date]}건)</option>`).join("") : '<option value="">목록을 검색해 주세요</option>';
    dateSelect.value = dates.includes(previous) ? previous : (dates.find(date => date >= today) || dates[dates.length - 1] || "");
    pdfAll.disabled = !dates.length;
  }
  panel.querySelector('[data-action="pdf-folder"]').addEventListener("click", async () => {
    try {
      const response = await chrome.runtime.sendMessage({ type: "NOIDB_PDF_FOLDER", date: dateSelect.value });
      if (!response?.ok) throw new Error(response?.error || "폴더를 열지 못했습니다.");
      if (!response.dated) pdfBatch.textContent = `${dateSelect.value || "이 날짜"} 폴더가 아직 없어 쉽먼트출력세트 폴더를 열었습니다. PDF를 받으면 날짜 폴더가 생깁니다.`;
    } catch (error) { pdfBatch.textContent = error.message; }
  });
  // 0.9.16(2026-11-25): 그 날짜 쉽먼트가 끝난 쪽이면 다음 쪽으로 넘기지 않고 멈춘다. '확인할 쪽' 기본값 1쪽.
  // 0.9.15(2026-11-12): 70쪽까지 돌던 문제 → '확인할 쪽' 칸(1~5쪽, 기본 5쪽)에서 고른 쪽까지만 확인하고 받는다.
  // 0.9.14(2026-10-29): 쿠팡 목록이 10개씩 쪽으로 나뉘어 있어 첫 쪽만 받던 문제 → 쪽 번호(1·2·3…)와 다음(›) 버튼을 스스로 눌러 끝까지 받는다.
  const pageSignature = () => shipmentRows().map(row => row.shipment).join(",");
  const clickTarget = element => element.closest("a, button, li") || element;
  const isDisabled = element => { const target = clickTarget(element); return Boolean(target.disabled) || target.getAttribute("aria-disabled") === "true" || [target, target.parentElement].some(node => /disabled/i.test(node?.className || "")); };
  const isActive = element => { const target = clickTarget(element); return target.getAttribute("aria-current") === "page" || [target, target.parentElement].some(node => /(^|[\s_-])(active|current|selected|on)([\s_-]|$)/i.test(node?.className || "")); };
  /** 표 아래 쪽 번호 묶음(숫자 3개 이상이 한 곳에 모인 곳)을 찾는다. 없으면 null(한 쪽짜리 목록). */
  function pagination() {
    const leaves = [...document.querySelectorAll("a, button, li, span")].filter(element => !element.closest("table") && /^\d{1,3}$/.test(textOf(element)) && !element.querySelector("a, button, li, span, div"));
    for (const leaf of leaves) {
      let node = leaf.parentElement;
      for (let depth = 0; node && depth < 4; depth += 1, node = node.parentElement) {
        const inside = leaves.filter(item => node.contains(item));
        const values = [...new Set(inside.map(item => Number(textOf(item))))];
        if (values.length < 3) continue;
        const items = [...new Map(inside.map(item => [clickTarget(item), { value: Number(textOf(item)), target: clickTarget(item), active: isActive(item) }])).values()];
        const arrows = [...node.querySelectorAll("a, button, li")].filter(item => !/\d/.test(textOf(item)) && !item.querySelector("a, button, li"));
        const last = inside[inside.length - 1];
        const after = arrows.filter(item => last.compareDocumentPosition(item) & Node.DOCUMENT_POSITION_FOLLOWING);
        return { items, next: after[after.length - 1] || null };
      }
    }
    return null;
  }
  async function waitFor(condition, ms) { const end = Date.now() + ms; while (Date.now() < end) { if (condition()) return true; await wait(250); } return false; }
  pdfAll.addEventListener("click", async () => {
    const date = dateSelect.value;
    if (!date || !shipmentRows().length) { pdfBatch.textContent = "이 화면에 쉽먼트 목록이 없습니다. 쿠팡에서 검색한 뒤 다시 눌러 주세요."; return; }
    pdfBusy = true; pdfAll.disabled = dateSelect.disabled = pageSelect.disabled = true;
    const maxPages = Math.min(5, Math.max(1, Number(pageSelect.value) || 1));
    let capped = false, stoppedEarly = false;
    const done = await readDone();
    let clicked = 0, skipped = 0, total = 0, pages = 0;
    const seen = new Set(), visitedPages = new Set();
    let found = 0, ended = false;
    async function readPage(label) {
      pages += 1;
      const pageRows = shipmentRows();
      const hits = pageRows.filter(item => item.date === date).length;
      const lastDate = pageRows.length ? pageRows[pageRows.length - 1].date : "";
      // 이 쪽에 그 날짜가 있는데 쪽의 마지막 줄이 다른 날짜면 그 날짜는 여기서 끝. 이미 찾은 뒤 이 쪽에 하나도 없어도 끝.
      ended = hits > 0 ? lastDate !== date : found > 0;
      found += hits;
      for (const row of pageRows.filter(item => item.date === date && !seen.has(item.shipment))) {
        seen.add(row.shipment); total += 1;
        for (const [kind, button, name] of [["Label", row.label, "Label"], ["ManiFest", row.manifest, "내역서"]]) {
          if (!button) continue;
          if (done[`${row.shipment}:${kind}`]) { skipped += 1; continue; }
          pdfBatch.textContent = `${date} 쉽먼트 ${total}건째${label} 받는 중… ${row.shipment} ${name}`;
          button.click();
          clicked += 1;
          await wait(2500);
        }
      }
    }
    try {
      await readPage("");
      for (let guard = 0; guard < 60; guard += 1) {
        const pager = pagination();
        if (!pager) break;
        if (ended) { stoppedEarly = true; break; }
        if (pages >= maxPages) { capped = true; break; }
        for (const item of pager.items) if (item.active) visitedPages.add(item.value);
        const nextPage = pager.items.filter(item => !visitedPages.has(item.value)).sort((a, b) => a.value - b.value)[0];
        if (nextPage) {
          visitedPages.add(nextPage.value);
          pdfBatch.textContent = `${date}: ${nextPage.value}쪽으로 넘어가는 중…`;
          const before = pageSignature();
          nextPage.target.click();
          await waitFor(() => pageSignature() !== before, 6000);
          await wait(600);
          await readPage(` (${nextPage.value}쪽)`);
          continue;
        }
        if (pager.next && !isDisabled(pager.next)) {
          const before = `${pager.items.map(item => item.value).join(",")}|${pageSignature()}`;
          pdfBatch.textContent = `${date}: 다음 쪽 묶음으로 넘어가는 중…`;
          clickTarget(pager.next).click();
          const changed = await waitFor(() => { const now = pagination(); return !now || `${now.items.map(item => item.value).join(",")}|${pageSignature()}` !== before; }, 6000);
          if (!changed) break;
          await wait(600);
          await readPage(" (다음 쪽 묶음)");
          continue;
        }
        break;
      }
      if (!total) { pdfBatch.textContent = `${date} 쉽먼트를 찾지 못했습니다. 쿠팡에서 검색한 뒤 다시 눌러 주세요.`; return; }
      // 저장이 다 끝나면(최대 90초) NOID-B 날짜 작업 화면을 열어 출력세트를 자동으로 만든다.
      const failedBefore = pdfFailed;
      pdfBatch.textContent = `${date} 쉽먼트 ${total}건(${pages}쪽 확인${stoppedEarly ? " · 이 날짜 끝" : ""}${capped ? ` · 선택한 ${maxPages}쪽까지만(더 있으면 확인할 쪽을 올려 주세요)` : ""}): 새로 받기 ${clicked}개${skipped ? ` · 이미 받은 ${skipped}개 건너뜀` : ""}. G드라이브 저장을 기다리는 중…`;
      const deadline = Date.now() + 90000;
      while (Date.now() < deadline && (pendingSaves > 0 || Date.now() - lastPdfEventAt < 3000)) await wait(500);
      if (pdfFailed > failedBefore || pendingSaves > 0) {
        pdfBatch.textContent = `${date}: 저장하지 못한 PDF가 있어 출력세트를 자동으로 만들지 않았습니다. 아래 결과를 확인한 뒤 다시 눌러 주세요.`;
      } else {
        await chrome.runtime.sendMessage({ type: "NOIDB_OPEN_OUTPUT_SET", date }).catch(() => null);
        pdfBatch.textContent = `${date} 쉽먼트 ${total}건(${pages}쪽 확인${stoppedEarly ? " · 이 날짜 끝" : ""}${capped ? ` · 선택한 ${maxPages}쪽까지만(더 있으면 확인할 쪽을 올려 주세요)` : ""}) 저장 끝 (새로 ${clicked}개${skipped ? ` · 이미 받은 ${skipped}개` : ""}). NOID-B에서 출력세트를 자동으로 만드는 중입니다.`;
      }
    } finally { pdfBusy = false; pdfAll.disabled = dateSelect.disabled = pageSelect.disabled = false; }
  });
  placePanel();
  refreshDates();
  setInterval(() => { placePanel(); refreshDates(); }, 1000);
})();
